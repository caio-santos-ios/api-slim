namespace api_slim.src.Shared.DTOs
{
    public class LoginDTO
    {
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}