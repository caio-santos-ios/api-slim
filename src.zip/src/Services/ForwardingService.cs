using System.Net.Http.Headers;
using api_slim.src.Interfaces;
using api_slim.src.Models;
using api_slim.src.Models.Base;
using api_slim.src.Shared.DTOs;
using api_slim.src.Shared.Utils;
using MongoDB.Bson;
using Newtonsoft.Json;

namespace api_slim.src.Services
{
    public class ForwardingService(ITelemedicineHistoricService telemedicineHistoricService, ITelemedicineHistoricRepository telemedicineHistoricRepository, ICustomerRecipientRepository customerRecipientRepository) : IForwardingService
    {
        private readonly HttpClient client = new();
        private readonly string uri = Environment.GetEnvironmentVariable("URI_RAPIDOC") ?? "";
        private readonly string clientId = Environment.GetEnvironmentVariable("CLIENT_ID_RAPIDOC") ?? "";
        private readonly string token = Environment.GetEnvironmentVariable("TOKEN_RAPIDOC") ?? "";

        #region  READ
        public async Task<ResponseApi<List<dynamic>>> GetAllAsync(GetAllDTO request)
        {
            try
            {
                string query = "";
                
                request.QueryParams.TryGetValue("status", out string? status);
                // request.QueryParams.TryGetValue("beneficiaryUuid", out string? beneficiaryUuid);
                
                if(!string.IsNullOrEmpty(status)) query += $"?status={status}";
                // if(!string.IsNullOrEmpty(beneficiaryUuid)) query += $"&beneficiaryUuid={beneficiaryUuid}";
                System.Console.WriteLine(query);
                var requestHeader = new HttpRequestMessage(HttpMethod.Get, $"{uri}/beneficiary-medical-referrals{query}");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", clientId);
                
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);

                string jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic? result = JsonConvert.DeserializeObject(jsonResponse);

                List<dynamic> list = [];
                foreach (dynamic item in result!)
                {    
                    Util.ConsoleLog(item);
                    BsonDocument bson = BsonDocument.Parse(item.ToString());

                    list.Add(new {
                        id = item.uuid.ToString(),                
                        recipientDescription = item.beneficiary.name.ToString(),
                        recipienId = item.beneficiary.uuid.ToString(),
                        cpf = item.beneficiary.cpf.ToString(),
                        status = item.status.ToString(),
                        createdAt = bson.Contains("createdAt") ? bson["createdAt"].ToString() : "",
                        urlPath = bson.Contains("urlPath") ? bson["urlPath"].ToString() : "",
                        specialtyId = bson.Contains("specialty") ? bson["specialty"]["uuid"].ToString() : "",
                    });                 
                }
                return new(list);
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        public async Task<ResponseApi<List<dynamic>>> GetByBeneficiaryIdAsync(string beneficiaryId)
        {
            try
            {
                ResponseApi<CustomerRecipient?> customer = await customerRecipientRepository.GetByIdAsync(beneficiaryId);

                var requestHeader = new HttpRequestMessage(HttpMethod.Get, $"{uri}/beneficiary-medical-referrals");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", clientId);
                
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);

                string jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic? result = JsonConvert.DeserializeObject(jsonResponse);

                List<dynamic> list = [];
                foreach (dynamic item in result!)
                {    
                    if(customer.Data is null) continue;
                    if(customer.Data.Cpf.Replace(".", "").Replace("-", "") != item.beneficiary.cpf.ToString()) continue;

                    BsonDocument bson = BsonDocument.Parse(item.ToString());
                    ResponseApi<TelemedicineHistoric?> existed = await telemedicineHistoricRepository.GetByParentIdAsync(item.uuid.ToString(), "Encaminhamento");
                    string status = item.status.ToString();
                    string beneficiaryUrl = "";

                    if(existed.Data is not null)
                    {
                        var historic = await GetByIdAsync(existed.Data.ParentUuid);
                        if(historic.Data is not null)
                        {
                            beneficiaryUrl = historic.Data.beneficiaryUrl;
                        };

                        status = "SCHEDULED";
                    };

                    list.Add(new {
                        id = item.uuid.ToString(),                
                        recipientDescription = item.beneficiary.name.ToString(),
                        recipienId = item.beneficiary.uuid.ToString(),
                        cpf = item.beneficiary.cpf.ToString(),
                        status,
                        createdAt = bson.Contains("createdAt") ? bson["createdAt"].ToString() : "",
                        urlPath = bson.Contains("urlPath") ? bson["urlPath"].ToString() : "",
                        specialtyId = bson.Contains("specialty") ? bson["specialty"]["uuid"].ToString() : "",
                        specialtyName = bson.Contains("specialty") ? bson["specialty"]["name"].ToString() : "",
                        beneficiaryUrl
                    });                 
                };
                
                return new(list);
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        public async Task<ResponseApi<dynamic?>> GetByIdAsync(string id)
        {
            try
            {
                var requestHeader = new HttpRequestMessage(HttpMethod.Get, $"{uri}/appointments/{id}");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", clientId);
                
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);

                string jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic? result = JsonConvert.DeserializeObject(jsonResponse);

                dynamic obj = new {};
                if(result is not null)
                {
                    obj = new
                    {
                        result.beneficiaryUrl
                    };
                }
                
                return new(obj);
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        public async Task<ResponseApi<List<dynamic>>> GetSpecialtiesAllAsync()
        {
            try
            {
                var requestHeader = new HttpRequestMessage(HttpMethod.Get, $"{uri}/specialties");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", clientId);
                
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);
                response.EnsureSuccessStatusCode();
                string jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic? result = JsonConvert.DeserializeObject(jsonResponse);

                List<dynamic> list = [];
                foreach (dynamic item in result!)
                {                    
                    list.Add(new {
                        id = item.uuid.ToString(),                
                        name = item.name.ToString()
                    });                            
                }
                return new(list);
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        public async Task<ResponseApi<List<dynamic>>> GetSpecialtyAvailabilityAllAsync(string specialtyUuid, string beneficiaryUuid)
        {
            try
            {
                DateTime date = DateTime.UtcNow;
                DateTime endDate = date.AddMonths(12);
                var requestHeader = new HttpRequestMessage(HttpMethod.Get, $"{uri}/specialty-availability?specialtyUuid={specialtyUuid}&dateInitial={date.ToString("dd/MM/yyyy")}&dateFinal={endDate.ToString("dd/MM/yyyy")}&beneficiaryUuid={beneficiaryUuid}");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", clientId);
                
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    dynamic? resultError = JsonConvert.DeserializeObject(error);

                    string msg = resultError!.message.ToString();
                    return new(null, 400, msg);
                };

                response.EnsureSuccessStatusCode();
                string jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic? result = JsonConvert.DeserializeObject(jsonResponse);

                List<dynamic> list = [];
                foreach (dynamic item in result!)
                {                    
                    list.Add(new {
                        id = item.uuid.ToString(),   
                        name = $"{item.date.ToString()} - {item.from.ToString()} Até {item.to.ToString()}",              
                        date = item.date.ToString(),
                        startTime = item.from.ToString(),
                        endTime = item.to.ToString(),
                    });                            
                }

                return new(list);
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        public async Task<ResponseApi<List<dynamic>>> GetBeneficiaryMedicalReferralsAsync()
        {
            try
            {
                var requestHeader = new HttpRequestMessage(HttpMethod.Get, $"{uri}/beneficiary-medical-referrals");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", clientId);
                
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);
                response.EnsureSuccessStatusCode();
                string jsonResponse = await response.Content.ReadAsStringAsync();
                
                dynamic? result = JsonConvert.DeserializeObject(jsonResponse);
                List<dynamic> list = [];
                
                foreach (dynamic item in result!)
                {                    
                    list.Add(new {
                        id = item.uuid.ToString(),   
                        name = item.beneficiary.name.ToString(),      
                        beneficiaryId = item.beneficiary.uuid.ToString()
                    });                            
                }

                return new(list);
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        #endregion
        #region  CREATE
        public async Task<ResponseApi<dynamic?>> CreateAsync(CreateForwardingDTO request)
        {
            try
            {
                var requestHeader = new HttpRequestMessage(HttpMethod.Post, $"{uri}/appointments");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", $"{clientId}");
                requestHeader.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                
                dynamic item = new
                {
                    approveAdditionalPayment = true,
                    availabilityUuid = request.AvailabilityUuid,
                    beneficiaryUuid = request.BeneficiaryUuid,
                    specialtyUuid = request.SpecialtyUuid
                };

                string jsonPayload = System.Text.Json.JsonSerializer.Serialize(item);

                var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/vnd.rapidoc.tema-v2+json");

                content.Headers.ContentType!.CharSet = null; 

                requestHeader.Content = content;

                var responseRapidoc = await client.SendAsync(requestHeader);
                if (!responseRapidoc.IsSuccessStatusCode)
                {
                    var error = await responseRapidoc.Content.ReadAsStringAsync();
                    dynamic? resultError = JsonConvert.DeserializeObject(error);

                    string msg = resultError!.message.ToString();
                    return new(null, 400, msg);
                };

                string jsonResponse = await responseRapidoc.Content.ReadAsStringAsync();
                dynamic? result = Newtonsoft.Json.JsonConvert.DeserializeObject(jsonResponse);

                await telemedicineHistoricService.CreateAsync(new ()
                {
                    Status = "Agendado",
                    Date = request.Date,
                    Time = request.Time,
                    RecipientId = request.BeneficiaryUuid,
                    SpecialistId = request.SpecialtyUuid,
                    RecipientName = request.BeneficiaryName,
                    SpecialistName = request.SpecialtyName,
                    CreatedBy = request.CreatedBy,
                    Type = "Encaminhamento",
                    ParentId = request.ParentId,
                    ParentUuid = result is null ? "" : result.uuid,
                    BeneficiaryCPF = request.BeneficiaryCPF
                });

                return new(null, 201, "Encaminhamento feito com sucesso");
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        #endregion
        #region  UPDATE
        public async Task<ResponseApi<dynamic?>> CancelAsync(CancelForwardingDTO request)
        {
            try
            {
                var requestHeader = new HttpRequestMessage(HttpMethod.Delete, $"{uri}/appointments/{request.Id}");
                requestHeader.Headers.Add("Authorization", $"Bearer {token}");
                requestHeader.Headers.Add("clientId", $"{clientId}");
                var content = new StringContent(string.Empty);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.rapidoc.tema-v2+json");
                requestHeader.Content = content;
                var response = await client.SendAsync(requestHeader);
                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    dynamic? resultError = JsonConvert.DeserializeObject(error);

                    string msg = resultError!.message.ToString();
                    return new(null, 400, msg);
                };

                string jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic? result = Newtonsoft.Json.JsonConvert.DeserializeObject(jsonResponse);

                await telemedicineHistoricService.CreateAsync(new ()
                {
                    Status = "Cancelado",
                    Date = request.Date,
                    Time = request.Time,
                    RecipientId = request.BeneficiaryUuid,
                    SpecialistId = request.SpecialtyUuid,
                    RecipientName = request.BeneficiaryName,
                    SpecialistName = request.SpecialtyName,
                    CreatedBy = request.CreatedBy,
                    Type = "Encaminhamento"
                });

                return new(null, 204, "Cancelado com sucesso");
            }
            catch
            {
                return new(null, 500, "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
            }
        }
        #endregion
    }
}