using api_slim.src.Models.Base;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace api_slim.src.Models
{
    public class ServiceModule : ModelBase
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;
        
        [BsonElement("code")]
        public string Code {get;set;} = string.Empty;
        
        [BsonElement("identification")]
        public string Identification {get;set;} = string.Empty;

        [BsonElement("name")]
        public string Name {get;set;} = string.Empty;

        [BsonElement("description")]
        public string Description {get;set;} = string.Empty;

        [BsonElement("planId")]
        public string PlanId {get;set;} = string.Empty;

        [BsonElement("price")]
        public decimal Price { get; set; }

        [BsonElement("cost")]
        public decimal Cost {get;set;}

        [BsonElement("image")]
        public string Image { get; set; } = string.Empty;

        [BsonElement("type")]
        public string Type { get; set; } = string.Empty;

        [BsonElement("rapiDocId")]
        public string RapiDocId { get; set; } = string.Empty;
    }
}