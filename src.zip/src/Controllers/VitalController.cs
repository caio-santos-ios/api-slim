using System.Security.Claims;
using api_slim.src.Interfaces;
using api_slim.src.Models;
using api_slim.src.Models.Base;
using api_slim.src.Shared.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace api_slim.src.Controllers
{
    [Route("api/vitals")]
    [ApiController]
    public class VitalController(IVitalService service) : ControllerBase
    {
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            PaginationApi<List<dynamic>> response = await service.GetAllAsync(new(Request.Query));
            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(string id)
        {
            ResponseApi<dynamic?> response = await service.GetByIdAggregateAsync(id);
            return StatusCode(response.StatusCode, new { response.Result });
        }

        [Authorize]
        [HttpGet("beneficiary/{period}")]
        public async Task<IActionResult> GetByBeneficiaryIdAsync(string period)
        {
            string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            System.Console.WriteLine(userId);
            ResponseApi<Vital?> response = await service.GetByBeneficiaryIdAsync(userId, period);
            return StatusCode(response.StatusCode, new { response.Result });
        }

        [Authorize]
        [HttpGet("beneficiary-all/{startDate}/{endDate}")]
        public async Task<IActionResult> GetByBeneficiaryAllAsync(string startDate, string endDate)
        {
            string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<List<Vital>> response = await service.GetByBeneficiaryAllAsync(userId, startDate, endDate);
            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpGet("beneficiary")]
        public async Task<IActionResult> GetByBeneficiaryAsync()
        {
            string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<Vital?> response = await service.GetByBeneficiaryAsync(userId);
            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateVitalDTO vital)
        {
            if (vital == null) return BadRequest("Dados inválidos.");
            vital.CreatedBy = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            vital.BeneficiaryId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<Vital?> response = await service.CreateAsync(vital);

            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpPost("iso")]
        public async Task<IActionResult> CreateISO([FromBody] CreateVitalDTO vital)
        {
            if (vital == null) return BadRequest("Dados inválidos.");
            vital.CreatedBy = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            vital.BeneficiaryId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<Vital?> response = await service.CreateISOAsync(vital);

            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpPut]
        public async Task<IActionResult> Update([FromBody] UpdateVitalDTO vital)
        {
            if (vital == null) return BadRequest("Dados inválidos.");
            vital.UpdatedBy = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<Vital?> response = await service.UpdateAsync(vital);

            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpPut("iso")]
        public async Task<IActionResult> UpdateISO([FromBody] UpdateVitalDTO vital)
        {
            if (vital == null) return BadRequest("Dados inválidos.");
            vital.UpdatedBy = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<Vital?> response = await service.UpdateISOAsync(vital);

            return StatusCode(response.StatusCode, new { response.Result });
        }
        
        [Authorize]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
            ResponseApi<Vital> response = await service.DeleteAsync(id, userId);

            return StatusCode(response.StatusCode, new { response.Result });
        }
    }
}